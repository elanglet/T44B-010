<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajout d'un article - Bienvenue sur MonJournal !</title>
</head>
<body>
    <h1>
        Bienvenue sur MonJournal !
    </h1>
    <h2>
        Ajout d'un article 
    </h2>
    
    <!-- Commentaire HTML -->
    <form action="enregistrer.php" method="post">
        <div>
            <label for="titre">Titre : </label>
            <input type="text" id="titre" name="titre" />
        </div>
        <div>
            <label for="intro">Introduction : </label>
            <textarea id="intro" name="intro" rows="4" cols="60"></textarea>
        </div>
        <div>
            <label for="texte">Introduction : </label>
            <textarea id="texte" name="texte" rows="10" cols="60"></textarea>
        </div>
        <div>
            <button type="submit">Enregistrer</button>
        </div>
    </form>

</body>
</html>
