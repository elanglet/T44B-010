<?php

// Classe d'exception personnalisée
class JournalException extends Exception {

    // On hérite de la notion de message et de code...
    // et des méthodes getMessage(), getCode() et du constructeur !
}