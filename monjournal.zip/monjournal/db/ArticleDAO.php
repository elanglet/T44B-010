<?php

class ArticleDAO {

    // On simule la table article
    private static ?Auteur $auteur = null;
    private static ?array $listeArticles = null;

    private static function init() {
        self::$auteur = new Auteur("elanglet", "password", "Etienne", "LANGLET");
        self::$listeArticles = [
            new Article(1, 
                        "Premier Article", 
                        "Intro de premier article", 
                        "Texte de premier article", 
                        true, 
                        self::$auteur
            ),
            new Article(2, 
                        "Second Article", 
                        "Intro de second article", 
                        "Texte de second article", 
                        true, 
                        self::$auteur
            )        
        ];
    }

    public static function rechercherTousLesArticles(): array {
        if(self::$auteur == null && self::$listeArticles == null)
            self::init();

        return self::$listeArticles;
    }

    public static function rechercherArticleParId(int $id): Article {
        if(self::$auteur == null && self::$listeArticles == null)
            self::init();

        foreach(self::$listeArticles as $article) {
            if($article->getId() === $id)
                return $article;
        }
        throw new JournalException("Article introuvable.");
    }

    public static function ajouterArticle(Article $article): int {
        if(self::$auteur == null && self::$listeArticles == null)
            self::init();

        self::$listeArticles[] = $article;
        return $article->getId();
    }

}
