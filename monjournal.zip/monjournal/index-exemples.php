<?php
    require_once('./classes/Archivable.php');
    require_once('./classes/Publication.php');
    require_once('./classes/Article.php');
    require_once('./classes/Breve.php');
    require_once('./classes/Auteur.php');
    require_once('./exceptions/JournalException.php');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenue sur MonJournal !</title>
</head>
<body>
    <h1>Bienvenue sur MonJournal !</h1>

    <?php
        echo "Nombre de publications : " . Publication::getNbPublications() . "<br/>";

        // Création de l'objet
        $p = new Publication(1, "Mon titre");

        echo "Nombre de publications : " . Publication::getNbPublications() . "<br/>";

        // Accès aux membres
        $p->publier();
        echo $p->afficher();

        echo "Id : " . $p->getId() . "<br/>";
        echo "Publié ? : " . $p->getPublie() . "<br/>";

        echo "<pre>";
        print_r($p);
        echo "</pre>";
    ?>
    <h2>Les articles</h2>
    <?php
        $a = new Article(
            1, 
            "Premier article", 
            "Un article extrêmement intéressant !", 
            "Bla bla bla bla ..."
        );

        // Méthodes héritées
        $a->publier();
        echo $a->afficher();
    ?>
    <h2>Les archivables</h2>
    <?php
        $b = new Breve(1, "Flash Info !");
        $auteur = new Auteur("elanglet", "password", "Etienne", "LANGLET");

        // On imagine un ensemble avec tous les objets métiers du site...
        $tab = [$a, $b, $auteur];

        foreach($tab as $element) {
            // On test si l'objet est archivable...
            if($element instanceof Archivable) {
                $element->archiver();
            }   
        }
    ?>
    <h2>Les exceptions</h2>
    <?php
        try {
            $a->setIntro(null);
            echo "Intro : " . $a->getIntro() . "<br/>";
        }
        catch(JournalException $e) {
            echo "Erreur ! Message : " . $e->getMessage() . "<br/>";
        }

    ?>

</body>
</html>