<?php

interface Archivable {

    // 'public' est facultatif. Par contre il ne faut pas utiliser 'abstract'
    public function archiver(); 

}