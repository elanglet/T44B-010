<?php

class Publication {

    // Définition des attributs
    
    // Avant PHP 8 : 
    // public $id;
    // public $titre;

    // Avec PHP 8 : 
    private int $id;
    private string $titre;
    private bool $publie = false;        // Valeur par défuat pour un attribut

    // Attribut de classe pour compter le nombre de publications
    // On initialise à 0. Obligatoire avant de pouvoir incrémenter dans le constructeur
    private static int $nbPublications = 0;

    // Définition d'un constructeur pour initialiser les attributs
    public function __construct(int $id, string $titre, bool $publie = false) {
        $this->id = $id;
        $this->titre = $titre;
        $this->publie = $publie;
        // On incrémente le compteur
        self::$nbPublications++;
    }

    // Définition des méthodes
    public function afficher(): string {
        if($this->publie) {
            // Retourner le titre dans une balise <h3>
            return "<h3>" . $this->titre . "</h3>";
        }
        return "";
    }

    public function publier(): void {
        // Passer l'attribut $publie à true
        $this->publie = true;
    }

    public function depublier(): void {
        // Passer l'attribut $publie à false
        $this->publie = false;
    }

    /**
     * Get the value of id
     *
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Get the value of titre
     *
     * @return string
     */
    public function getTitre(): string
    {
        return $this->titre;
    }

    /**
     * Set the value of titre
     *
     * @param string $titre
     *
     * @return self
     */
    public function setTitre(string $titre): self
    {
        $this->titre = $titre;

        return $this;
    }

    /**
     * Get the value of publie
     *
     * @return bool
     */
    public function getPublie(): bool
    {
        return $this->publie;
    }

    /**
     * Get the value of nbPublications
     *
     * @return int
     */
    public static function getNbPublications(): int
    {
        return self::$nbPublications;
    }
}