<?php

class Auteur implements Archivable {

    private string $identifiant;
    private string $motDePasse;
    private string $prenom;
    private string $nom;

    public function __construct(
        string $identifiant, string $motDePasse, 
        string $prenom, string $nom
    ) {
        $this->identifiant = $identifiant;
        $this->motDePasse = $motDePasse;
        $this->prenom = $prenom;
        $this->nom = $nom;
    }

    /**
     * Get the value of identifiant
     *
     * @return string
     */
    public function getIdentifiant(): string
    {
        return $this->identifiant;
    }

    /**
     * Get the value of motDePasse
     *
     * @return string
     */
    public function getMotDePasse(): string
    {
        return $this->motDePasse;
    }

    /**
     * Set the value of motDePasse
     *
     * @param string $motDePasse
     *
     * @return self
     */
    public function setMotDePasse(string $motDePasse): self
    {
        $this->motDePasse = $motDePasse;

        return $this;
    }

    /**
     * Get the value of prenom
     *
     * @return string
     */
    public function getPrenom(): string
    {
        return $this->prenom;
    }

    /**
     * Set the value of prenom
     *
     * @param string $prenom
     *
     * @return self
     */
    public function setPrenom(string $prenom): self
    {
        $this->prenom = $prenom;

        return $this;
    }

    /**
     * Get the value of nom
     *
     * @return string
     */
    public function getNom(): string
    {
        return $this->nom;
    }

    /**
     * Set the value of nom
     *
     * @param string $nom
     *
     * @return self
     */
    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    // Redéfinition de la méthode archiver()
    public function archiver() {
        echo "Archivage de l'auteur...<br/>";
    }
}