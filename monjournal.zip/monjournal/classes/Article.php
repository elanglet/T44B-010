<?php

class Article extends Publication implements Archivable {

    private string $intro;
    private string $texte;
    private string $date;

    // Référence à l'auteur
    private Auteur $auteur;

    // Il faut penser à initialiser les attributs de la super-classe !
    public function __construct(
        int $id, string $titre,  
        string $intro, string $texte, 
        bool $publie = false,
        Auteur $auteur = null
    ) {
        // $this->id = $id; -> Interdit : id est private dans Publication

        // Pour initialiser les attributs hérités, on appelle le constructeur de la super-classe
        parent::__construct($id, $titre, $publie);

        // Initialisation des attributs propres à la classe
        $this->intro = $intro;
        $this->texte = $texte;
        $this->date = date('Y-m-d H:i:s');

        $this->auteur = $auteur;
    }

    /**
     * Get the value of intro
     *
     * @return string
     */
    public function getIntro(): string
    {
        return $this->intro;
    }

    /**
     * Set the value of intro
     *
     * @param string $intro
     *
     * @return self
     */
    public function setIntro(?string $intro): self
    {
        if($intro != null && strlen($intro) <= 255) {
            $this->intro = $intro;
            return $this;
        }
        else {
            // On lève une exception...
            throw new JournalException("Le texte d'introduction est incorrect.");
        }
    }

    /**
     * Get the value of texte
     *
     * @return string
     */
    public function getTexte(): string
    {
        return $this->texte;
    }

    /**
     * Set the value of texte
     *
     * @param string $texte
     *
     * @return self
     */
    public function setTexte(string $texte): self
    {
        if($texte != null && strlen($texte) <= 2000) {
            $this->texte = $texte;
            return $this;
        }
        else {
            throw new JournalException("La valeur de texte est incorrect.");
        }
    }

    /**
     * Get the value of date
     *
     * @return string
     */
    public function getDate(): string
    {
        return $this->date;
    }

    /**
     * Set the value of date
     *
     * @param string $date
     *
     * @return self
     */
    public function setDate(string $date): self
    {
        $this->date = $date;

        return $this;
    }

    // Redéfinition de la méthode afficher() de Publication
    // pour tenir compte des spécificités de Article
    public function afficher(): string {
        // Uniquement si l'article est publié....
        if($this->getPublie()) {
            // On appelle la méthode de la super-classe
            $contenu = parent::afficher();

            $contenu .= "<p>Ecrit le " . $this->date . "</p>";    
            $contenu .= "<p><i>" . $this->intro . "</i></p>";
            $contenu .= "<p>" . $this->texte . "</p>";

            return $contenu;
        }
        return "";
    }

    // Redéfinition de la méthode archiver()
    public function archiver() {
        echo "Archivage de l'article...<br/>";
    }

    /**
     * Get the value of auteur
     *
     * @return Auteur
     */
    public function getAuteur(): Auteur
    {
        return $this->auteur;
    }

    /**
     * Set the value of auteur
     *
     * @param Auteur $auteur
     *
     * @return self
     */
    public function setAuteur(Auteur $auteur): self
    {
        $this->auteur = $auteur;

        return $this;
    }
}

