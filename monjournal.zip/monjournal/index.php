<?php
    require_once('./classes/Archivable.php');
    require_once('./classes/Publication.php');
    require_once('./classes/Article.php');
    require_once('./classes/Breve.php');
    require_once('./classes/Auteur.php');
    require_once('./exceptions/JournalException.php');
    require_once('./db/ArticleDAO.php');

    $listeArticles = ArticleDAO::rechercherTousLesArticles();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenue sur MonJournal !</title>
</head>
<body>
    <h1>Bienvenue sur MonJournal !</h1>
    <?php
        foreach($listeArticles as $article) {
    ?>
            <h3>
                <?php echo $article->getTitre(); ?>
            </h3>
            <p>
                Ecrit par <?php echo $article->getAuteur()->getPrenom(); ?> <?php echo $article->getAuteur()->getNom(); ?>
                , le <?php echo $article->getDate(); ?>  
            </p>    
            <p>
                <i><?php echo $article->getIntro(); ?></i>
            </p>    
            <p>
                <a href="article.php?id=<?php echo $article->getId(); ?>">Lire la suite...</a>
            </p>
            <hr/>
    <?php
        }
    ?>
</body>
</html>





























