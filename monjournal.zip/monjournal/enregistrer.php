<?php
require_once('./classes/Archivable.php');
require_once('./classes/Publication.php');
require_once('./classes/Article.php');
require_once('./classes/Breve.php');
require_once('./classes/Auteur.php');
require_once('./exceptions/JournalException.php');
require_once('./db/ArticleDAO.php');

try {
    if(isset($_POST['titre']) && isset($_POST['intro']) && isset($_POST['texte'])) {
        $auteur = new Auteur("rdupont", "secret", "Robert", "DUPONT");
        $article = new Article(3, $_POST['titre'], $_POST['intro'], $_POST['texte'], true, $auteur);

        $idGenere = ArticleDAO::ajouterArticle($article);

        // header("Location: article.php?id=$idGenere");

        echo "<pre>";
        print_r($article);
        echo "</pre>";
    }
    else {
        // Invocation de ce script en GET, on redirige, vers le formulaire
        header("Location: ajouter.php");
    }
}
catch(Exception $e) {
    $messageErreur = $e->getMessage();
    include('./erreurs/erreur.php');
}
