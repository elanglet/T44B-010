<?php 

// require_once('classes/Publication.php');
// require_once('classes/Article.php');
// require_once('classes/JournalException.php');
// require_once('db/DBUtil.php');
// require_once('db/ArticlePDO.php');

require_once('autoload.php');

try {
    
    $pdo = new ArticlePDO();
    $lesArticles = $pdo->rechercherTousLesArticles(); 
    
?>
    <!DOCTYPE html>
    <html>
    	<head>
    		<title>Accueil - Bienvenue sur MonJournal !</title>
    	</head>	
    	<body>
    		<?php include('inc/lien.php'); ?>
    		<h1>Bienvenue sur MonJournal !</h1>    		
    		
    		<!-- En utilisant des blocs PHP, récupérer la liste des articles et les afficher. -->
    		<?php foreach($lesArticles as $article) { ?>
    		
        		<h3><?= $article->getTitre(); ?></h3>
        		<p>
        			Ecrit par <?= $article->getAuteur(); ?>, le <?= $article->getDate(); ?>
        		</p>
        		<p>
        			<a href="article.php?id=<?= $article->getId(); ?>">Lire la suite...</a>
        		</p>
        		<hr />
        		
    		<?php } ?>
    	</body>
    </html>

<?php 
}
catch(JournalException $e) {
    // On définit la variable 'message' utilisée par le script 'erreur.php'
    $message = $e->getMessage();
    // On inclut le script 'erreur.php'
    include('erreur.php');
}
?>