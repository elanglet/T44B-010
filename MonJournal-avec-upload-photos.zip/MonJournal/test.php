<?php

require_once('classes/Publication.php');
require_once('classes/Article.php');
require_once('classes/JournalException.php');
require_once('db/DBUtil.php');
require_once('db/ArticlePDO.php');



echo "<h2>Nb de publications : " . Publication::getNbPublications() . "</h2>";


// Instanciation de la classe...
$publi1 = new Publication(1, "Titre 1", "08/10/2020");

echo "<pre>";
print_r($publi1);
echo "</pre>";


$art1 = new Article(2, "Titre 2", "08/10/2020", "Texte de l'article.", "Etienne");

echo "<pre>";
print_r($art1);
echo "</pre>";

echo "<h2>Nb de publications : " . Publication::getNbPublications() . "</h2>";

echo "<h2>Tests BDD</h2>";
echo "<h3>Tous les articles</h3>";
$pdo = new ArticlePDO();

$lesArticles = $pdo->rechercherTousLesArticles();

echo "<pre>";
print_r($lesArticles);
echo "</pre>";

echo "<h3>Article par id</h3>";

$unArticle = $pdo->rechercherArticleParId(1);

echo "<pre>";
print_r($unArticle);
echo "</pre>";

echo "<h3>Ajout d'article</h3>";

$art2 = new Article(0, "Article depuis l'application", date('Y-m-d H:i:s'), "Texte de l'article.", "Etienne");

$idInsere = $pdo->ajouterArticle($art2);

echo "Id inséré : " . $idInsere;
