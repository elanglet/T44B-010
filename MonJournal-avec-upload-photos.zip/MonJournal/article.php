<?php

// require_once('classes/Publication.php');
// require_once('classes/Article.php');
// require_once('classes/JournalException.php');
// require_once('db/DBUtil.php');
// require_once('db/ArticlePDO.php');

require_once('autoload.php');

try {
    // Controles sur le paramètre 'id' transmis dans l'URL...     ->   article.php?id=23    /      $_GET['id]
    if(isset($_GET['id']) && is_numeric($_GET['id'])) {
        
        // On récupère l'article par son id
        $pdo = new ArticlePDO();
        $article = $pdo->rechercherArticleParId($_GET['id']);
        
        // On génère la structure de page HTML
?>
		<!DOCTYPE html>
        <html>
        	<head>
        		<title><?= $article->getTitre(); ?> - Bienvenue sur MonJournal !</title>
        	</head>	
        	<body>
        		<?php include('inc/lien.php'); ?>
        		<h1>Bienvenue sur MonJournal !</h1>  	
    			<h2><?= $article->getTitre(); ?></h2>
    			<p>
        			<b>Ecrit par <?= $article->getAuteur(); ?>, le <?= $article->getDate(); ?></b>
        		</p>
        		
        		<?php if(file_exists('img/article_' . $article->getId() . '.jpg')) { ?>
        			<p>
        				<img src="<?= 'img/article_' . $article->getId() . '.jpg' ?>" />
        			</p>
        		<?php } elseif(file_exists('img/article_' . $article->getId() . '.png')) { ?>
        		    <p>
        				<img src="<?= 'img/article_' . $article->getId() . '.png' ?>" />
        			</p>
        		<?php } ?>
        		
        		<p>
        			<?= $article->getTexte(); ?>
        		</p>
				<p>
					<a href="index.php">Retour à l'accueil</a>
				</p>
			</body>
		</html>
<?php 
    }
    else {
        // On définit la variable 'message' utilisée par le script 'erreur.php'
        $message = "Problème dans l'identifiant d'article transmis.";
        // On inclut le script 'erreur.php'
        include('erreur.php');        
    }
}
catch(JournalException $e) {
    // On définit la variable 'message' utilisée par le script 'erreur.php'
    $message = $e->getMessage();
    // On inclut le script 'erreur.php'
    include('erreur.php');  
}