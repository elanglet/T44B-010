<!DOCTYPE html>
<html>
	<head>
		<title>Erreur - Bienvenue sur MonJournal !</title>
	</head>	
	<body>
		<?php include('inc/lien.php'); ?>
		<h1>Bienvenue sur MonJournal !</h1>  	
		<h2>Erreur !!!</h2>
		<p>
			<?php if(isset($message)) { ?>
				Message : <?= $message ?>
			<?php }?>
		<p>
			<a href="index.php">Retour à l'accueil</a>
		</p>
	</body>
</html>