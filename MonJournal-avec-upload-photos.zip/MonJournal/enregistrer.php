<?php
// require_once('classes/Publication.php');
// require_once('classes/Article.php');
// require_once('classes/JournalException.php');
// require_once('db/DBUtil.php');
// require_once('db/ArticlePDO.php');

require_once('autoload.php');

try {
    session_start();
    if(isset($_SESSION['userAuth']) && !empty($_SESSION['userAuth'])) {
        // Session OK
        // 1. Contrôler et récupérer les données du tableau $_POST
        if(
            isset($_POST['titre']) && !empty($_POST['titre']) && 
            isset($_POST['texte']) && !empty($_POST['texte']) && 
            isset($_POST['auteur']) && !empty($_POST['auteur'])
        ) {
        
            // 2. Créer un objet Article à partir des données ( date en dur -> date() )
            $article = new Article(
                0, 
                $_POST['titre'],
                date('Y-m-d H:i:s'),
                $_POST['texte'],
                $_POST['auteur']
            );
            
            // 3. Insérer l'article en base avec la classe ArticlePDO
            $pdo = new ArticlePDO();
            $idGenere = $pdo->ajouterArticle($article);
            
            // TRANSFERT DE LA PHOTO
            // On récupère les informations du fichier transféré
            $photo = $_FILES['photo'];
            
            // On controle l'état du transfert
            switch ($photo['error']) {
                case UPLOAD_ERR_OK:
                    // Transfert OK
                
                    // On controle la validité du fichier.
                    // Type MIME
                    if($photo['type'] == 'image/jpeg' || $photo['type'] == 'image/png') {
                        // On gère le déplacement du fichier
                        $source = $photo['tmp_name'];
                        
                        if($photo['type'] == 'image/jpeg')
                            $extension = ".jpg";
                        else 
                            $extension = ".png";
                        
                        $destination = 'img/article_' . $idGenere . $extension;
                        
                        move_uploaded_file($source, $destination);
                    }
                    else {
                        throw new JournalException("Type de fichier non supporté.");                        
                    }
                    break;

                case UPLOAD_ERR_INI_SIZE:
                case UPLOAD_ERR_FORM_SIZE:
                    throw new JournalException("Taille de fichier trop importante.");                        
                    break;
                case UPLOAD_ERR_NO_TMP_DIR:
                case UPLOAD_ERR_CANT_WRITE:
                    throw new JournalException("Erreur d'enregistrement de la photo sur le serveur.");
                    break;
                case UPLOAD_ERR_PARTIAL:
                case UPLOAD_ERR_EXTENSION:
                    throw new JournalException("Erreur lors du transfert du fichier.");
                    break;
                default:
                    throw new JournalException("Erreur avec la photo...");
            }
            
            // 4. Rediriger vers la page d'affichage de l'article
            header('Location: article.php?id=' . $idGenere);
        
        }
        else {
            $message = "Erreur(s) dans le formulaire transmis.";
            include('erreur.php');
        }
    }
    else {
        // Session pas OK.
        header('Location: auth.php');
    }
}
catch(JournalException $e) {
    // On définit la variable 'message' utilisée par le script 'erreur.php'
    $message = $e->getMessage();
    // On inclut le script 'erreur.php'
    include('erreur.php');
}