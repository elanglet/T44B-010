<?php

// On définit une fonction qui recevra en paramètre le nom d'une classe.
// Cette fonction sera appelée par PHP à chaque fois que l'on fera référence à une classe dans le code

function monJournalAutoloader($classe) {
    // Par défaut, 'require_once' recherche les fichiers dans le répertoire courant et dans le 'include_path'.
    // Le 'include_path' peut être modifié par programmation avec la fonction 'set_include_path()'.
    
    // Ici, il s'agit d'ajouter le dossier 'classes' et le dossier 'db' au 'include_path'.
    // ATTENTION : Il faut exprimer ces chemins de manière absolue !
    
    
    $repClasses = dirname(__FILE__) . '/classes/';
    $repDb = dirname(__FILE__) . '/db/';
    
    // Une fois les répertoires identifiés, on les ajoutes au 'include_path'. 
    // Ils doivent être séparés par le séparateur de PATH ';' sous Windows, ':' sous Unix/Linux
    // La constante PATH_SEPARATOR, contient le séparateur de PATH en vigueur selon la plateforme.
    
    set_include_path(
        $repClasses . PATH_SEPARATOR . $repDb . PATH_SEPARATOR . get_include_path()
    );
    
    // Le fichier .php de la classe doit être inclus.
    require_once($classe . '.php');
}

// Il faut enregistrer cette fonction auprès de PHP
spl_autoload_register('monJournalAutoloader');



/*
 
    - AVEC UNE FONCTION ANONYME (CLOSURE)

  
spl_autoload_register(
    function($classe) {
        // Par défaut, 'require_once' recherche les fichiers dans le répertoire courant et dans le 'include_path'.
        // Le 'include_path' peut être modifié par programmation avec la fonction 'set_include_path()'.
        
        // Ici, il s'agit d'ajouter le dossier 'classes' et le dossier 'db' au 'include_path'.
        // ATTENTION : Il faut exprimer ces chemins de manière absolue !
        
        
        $repClasses = dirname(__FILE__) . '/classes/';
        $repDb = dirname(__FILE__) . '/db/';
        
        // Une fois les répertoires identifiés, on les ajoutes au 'include_path'.
        // Ils doivent être séparés par le séparateur de PATH ';' sous Windows, ':' sous Unix/Linux
        // La constante PATH_SEPARATOR, contient le séparateur de PATH en vigueur selon la plateforme.
        
        set_include_path(
            $repClasses . PATH_SEPARATOR . $repDb . PATH_SEPARATOR . get_include_path()
            );
        
        // Le fichier .php de la classe doit être inclus.
        require_once($classe . '.php');
    }  
);

*/
