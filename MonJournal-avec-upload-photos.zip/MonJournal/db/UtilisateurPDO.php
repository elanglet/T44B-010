<?php

class UtilisateurPDO {
    
    public function authentifier($identifiant, $motDePasse) {
        
        try {
            $db = DBUtil::connexion();

            $sql = "SELECT * FROM utilisateur WHERE identifiant=:identifiant AND motdepasse=:motdepasse";
            
            $st = $db->prepare($sql);
            $st->bindValue(':identifiant', $identifiant);
            $st->bindValue(':motdepasse', $motDePasse);
            $st->execute();
            
            if($st->fetch())
                return true;
            else
                return false;
        }
        catch(PDOException $e) {
            throw new JournalException("Erreur d'authentification.");
        }
        finally {
            // Liberer les ressources
            $db = null;
        }   
    }
}
