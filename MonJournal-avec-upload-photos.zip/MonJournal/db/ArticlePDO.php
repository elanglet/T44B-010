<?php

class ArticlePDO {
    
    /**
     * @return  array   Un tableau d'objets 'Article'.
     */
    public function rechercherTousLesArticles() {
        try {
            // 1. Connexion
            $db = DBUtil::connexion();
            
            // 2. Expression de la requête
            $sql = "SELECT * FROM article ORDER BY date DESC";
            
            // 3. Exécution de la requete (simple).
            
            /*
             * Au lieu de faire : 
             * 
             *      $st = $db->prepare($sql);
             *      $st->execute();
             *      
             * On peut utiliser :
             * 
             *      $resultat = $db->query($sql);
             */
            $resultat = $db->query($sql);
            
            // 4. Parcours du jeu d'enregistrement pour construire un tableau d'objets Article.
            $lesArticles = array();      
            foreach($resultat as $enreg) {
                // On créé un Article à partir de l'enreg.
                $a = new Article(
                    $enreg['id'],    
                    $enreg['titre'],    
                    $enreg['date'],    
                    $enreg['texte'],    
                    $enreg['auteur']                
                );
                // On l'ajout au tableau
                $lesArticles[] = $a;
            }
            
            // On retourne le tableau
            return $lesArticles;
        }
        catch(PDOException $e) {
            // Gestion des erreurs remontées par PDO...
            // On pourrait journaliser l'erreur....
            
            // On propage une exception utilisateur 
            throw new JournalException("Erreur de la récupération des articles.");
        }
        finally {
            // Liberer les ressources
            $db = null;
        }
    }
    
    /**
     * 
     * @param int $id       L'identifiant de l'article à récupérer.
     * @return Article      L'objet Article
     */
    public function rechercherArticleParId(int $id) { 
        try {
            $db = DBUtil::connexion();
            
            $sql = "SELECT * FROM article WHERE id=:id";
            
            $st = $db->prepare($sql);
            $st->bindValue(':id', $id);
            $st->execute();
            
            if($enreg = $st->fetch()) {
                $a = new Article(
                    $enreg['id'],
                    $enreg['titre'],
                    $enreg['date'],
                    $enreg['texte'],
                    $enreg['auteur']
                );
                
                return $a;
            }
            else {
                throw new JournalException("Article introuvable.");
            }
        }
        catch(PDOException $e) {
            throw new JournalException("Erreur de la récupération de l'article.");
        }
        finally {
            $db = null;
        }
    }
    
    /**
     * 
     * @param Article $article      L'objet Article à insérer en base.
     * @return int                  L'identifiant de l'article inséré.
     */
    public function ajouterArticle(Article $article) {
        try {
            $db = DBUtil::connexion();
            
            $db->beginTransaction(); // Démarrer une transaction.
            
            $sql = "INSERT INTO article(titre, date, texte, auteur) VALUES(:titre, :date, :texte, :auteur)";
            
            $st = $db->prepare($sql);
            $st->bindValue(':titre', $article->getTitre());
            $st->bindValue(':date', $article->getDate());
            $st->bindValue(':texte', $article->getTexte());
            $st->bindValue(':auteur', $article->getAuteur());
            $st->execute();
            
            $id = $db->lastInsertId();
            
            $db->commit(); // Validation de la transaction.
            
            return $id;
        }
        catch(PDOException $e) {
            $db->rollBack(); // Annulation de la transaction.
            throw new JournalException("Erreur de la récupération de l'article.");
        }
        finally {
            $db = null;
        }
    }
}
