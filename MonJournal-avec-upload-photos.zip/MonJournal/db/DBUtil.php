<?php

class DBUtil {
    
    // ATTENTION : Il faut que le pilote PDO utilisé soit chargé dans la configuration PHP (php.ini)
    const URL = "mysql:host=localhost;port=3306;dbname=monjournal";
    const USER = "monjournal";
    const PWD = "password";
    
    // Méthode de connexion à la base de données. ->      DBUtil::connexion();
    public static function connexion() {
        
        // On instancie la classe PDO pour créer la connexion.
        $db = new PDO(self::URL, self::USER, self::PWD);
        
        // On demande à PDO de générer des exceptions en cas d'erreur.
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        return $db;
    }
    
}
