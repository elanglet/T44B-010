<?php 
    session_start();
    if(isset($_SESSION['userAuth']) && !empty($_SESSION['userAuth'])) {
        // Session OK
?>
    <!DOCTYPE html>
    <html>
    <head>
    	<meta charset="UTF-8" />
    	<title>Rédaction d'un article - Bienvenue sur MonJournal !</title>
    </head>
    <body>
    	<?php include('inc/lien.php'); ?>
    	<h1>Bienvenue sur MonJournal !</h1>
    	<h2>Rédaction d'un article</h2>
    	
    	<form action="enregistrer.php" method="post" enctype="multipart/form-data">
    		
    		<label>Titre : </label>
    		<input type="text" name="titre" />
    		<br />
    	
    		<label>Texte : </label>
    		<textarea rows="8" cols="40" name="texte"></textarea>
    		<br />
    		
    		<label>Auteur : </label>
    		<input type="text" name="auteur" />
    		<br />
    	
    		<label>Photo : </label>
    		<input type="file" name="photo" />
    		<br />
    	
    		<button type="submit">Enregistrer</button>
    		
    	</form>
    	<p>
    		<a href="index.php">Retour à l'accueil</a>
    	</p>
    </body>
    </html>
<?php 
    }
    else {
        // Session pas Ok, on redirige vers l'authentification.
        header('Location: auth.php');
    }
?>