<?php

// Classe d'exception personnalisée.
class JournalException extends Exception {
    
    // On hérite des méthodes getMessage() et getCode(), ainsi que du constructeur.
    
}
