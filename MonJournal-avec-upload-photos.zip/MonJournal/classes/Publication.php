<?php

class Publication {
    
    // Définition des attributs
    private $id;
    private $titre;
    private $date;
    
    // On définit un attribut de classe (statique) pour compter le nombre d'instances
    private static $nbPublications = 0;
    
    /**
     * @return mixed
     */
    public static function getNbPublications()
    {
        // return Publication::$nbPublications;
        
        return self::$nbPublications;
    }

    // Définition d'un constructeur
    public function __construct($id, $titre = null, $date = null) {
        $this->id = $id;
        $this->titre = $titre;
        $this->date = $date;
        
        // On incrémente le nombre d'instances
        // Publication::$nbPublications++;
        // 
        // ou : 
        //
        self::$nbPublications++;
    }
    
    // Définition des méthodes
    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getTitre()
    {
        return $this->titre;
    }

    /**
     * @return mixed
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @param mixed $titre
     */
    public function setTitre($titre)
    {
        $this->titre = $titre;
    }

    /**
     * @param mixed $date
     */
    public function setDate($date)
    {
        $this->date = $date;
    }
    
}