<?php

class Article extends Publication {
    
    // Ajout d'attributs
    private $texte;
    private $auteur;
    
    public function __construct($id, $titre = null, $date = null, $texte = null, $auteur = null) {
        // Appel du constructeur de la super classe
        parent::__construct($id, $titre, $date);

        $this->texte = $texte;
        $this->auteur = $auteur;
    }
    
    // Et de méthodes ...
    /**
     * @return mixed
     */
    public function getTexte()
    {
        return $this->texte;
    }

    /**
     * @return mixed
     */
    public function getAuteur()
    {
        return $this->auteur;
    }

    /**
     * @param mixed $texte
     */
    public function setTexte($texte)
    {
        $this->texte = $texte;
    }

    /**
     * @param mixed $auteur
     */
    public function setAuteur($auteur)
    {
        $this->auteur = $auteur;
    }
    
}