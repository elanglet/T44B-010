<?php
// require_once('classes/Publication.php');
// require_once('classes/Article.php');
// require_once('classes/JournalException.php');
// require_once('db/DBUtil.php');
// require_once('db/ArticlePDO.php');
// require_once('db/UtilisateurPDO.php');

require_once('autoload.php');

try {
    if(
        isset($_POST['identifiant']) && !empty($_POST['identifiant']) &&
        isset($_POST['motdepasse']) && !empty($_POST['motdepasse'])
    ) {
        // POST
        
        $pdo = new UtilisateurPDO();
        $auth = $pdo->authentifier($_POST['identifiant'], $_POST['motdepasse']);
        
        if($auth) {
            // Auth réussie : on créé une session et on y stocke l'identifiant utilisateur.    
            session_start();
            $_SESSION['userAuth'] = $_POST['identifiant'];
            
            header('Location: rediger.php');
        }
        else
            header('Location: auth.php?error=true');
    }
    else {
        // GET : Affichage du formulaire        
?>
		<!DOCTYPE html>
        <html>
        	<head>
        		<title>Authentification - Bienvenue sur MonJournal !</title>
        	</head>	
        	<body>
        		<h1>Bienvenue sur MonJournal !</h1>  	
    			<h2>Authentification</h2>
    			
    			<?php if(isset($_GET['error']) && $_GET['error'] == 'true') { ?>
    				<p style="color: red;">
    					<b>Erreur d'authentification !</b>
    				</p>
    			<?php } ?>
    			
    			<form action="auth.php" method="post">
    				<label>Identifiant : </label>
    				<input type="text" name="identifiant" />
    				<br />
    				
    				<label>Mot de passe : </label>
    				<input type="password" name="motdepasse" />
    				<br />
    				
    				<button type="submit">Valider</button>
    			
    			</form>
			</body>
		</html>
<?php         
    }
}
catch(JournalException $e) {
    $message = $e->getMessage();
    include('erreur.php');
}