<?php
    if(!isset($_SESSION))
        session_start();
    
    if(isset($_SESSION['userAuth']) && !empty($_SESSION['userAuth'])) {
?>    
 		<p>
 			<a href="deconnexion.php">Déconnexion</a>
 		</p>
<?php   
    }
    else {
?>
 		<p>
 			<a href="auth.php">Connexion</a>
 		</p>
<?php 
    }
?>