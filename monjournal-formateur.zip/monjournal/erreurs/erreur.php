<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Erreur !!!</title>
</head>
<body>
    <h1>Erreur !!!</h1>
    <p>
        Une erreur est survenue pendant le traitement.
    </p>
    <?php 
        if(isset($messageErreur)) {
    ?>
            <h3>Message : </h3>
            <p>
                <?php echo $messageErreur; ?>
            </p>
    <?php
       }
    ?>
</body>
</html>
