<?php
try {
    require_once('./classes/Archivable.php');
    require_once('./db/DBUtil.php');
    require_once('./db/ArticleDAO.php');
    require_once('./classes/Auteur.php');
    require_once('./classes/Publication.php');
    require_once('./classes/Article.php');
    require_once('./exceptions/JournalException.php');

    // Il faut que le paramètre existe et qu'il soit numérique
    if(isset($_GET['id']) && is_numeric($_GET['id'])) {
        $article = ArticleDAO::rechercherArticleParId($_GET['id']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $article->getTitre(); ?> - Bienvenue sur MonJournal !</title>
</head>
<body>
    <h1>Bienvenue sur MonJournal !</h1>
    <h3>
        <?php echo $article->getTitre(); ?>
    </h3>
    <p>
        Ecrit par <?php echo $article->getAuteur()->getPrenom(); ?> <?php echo $article->getAuteur()->getNom(); ?>
        , le <?php echo $article->getDate(); ?>  
    </p>    
    <p>
        <i><?php echo $article->getIntro(); ?></i>
    </p>    
    <p>
        <?php echo $article->getTexte(); ?>
    </p>    
    <hr/>
    <p>
        <a href="index.php">Retour à l'accueil</a>
    </p>

</body>
</html>

<?php
    }
    else {
        // Redirection vers la page d'accueil car le paramètre id est incorrecte dans l'URL
        header("Location: index.php");
    }
}
catch(Exception $e) {
    // Si l'article n'est pas trouvé...
    $messageErreur = $e->getMessage();

    include('./erreurs/erreur.php');
}
?>
