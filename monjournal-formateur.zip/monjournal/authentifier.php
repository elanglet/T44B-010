<?php

require_once('./db/AuteurDAO.php');
require_once('./db/DBUtil.php');
require_once('./classes/Archivable.php');
require_once('./classes/Auteur.php');
require_once('./exceptions/JournalException.php');

if(isset($_POST['identifiant']) && isset($_POST['mot_de_passe'])) {
    // En POST : On traite le formulaire
    try {
        // Authentifier l'auteur
        $auteur = AuteurDAO::authentifier($_POST['identifiant'], $_POST['mot_de_passe']);

        // On créé une session 
        session_start();
        // On stocke l'auteur dans la session
        $_SESSION['_auth'] = $auteur;

        // Le rediriger vers le formulaire d'ajout d'article
        header("Location: ajouter.php");
    }
    catch(JournalException $e) {
        // Erreur d'authentification.
        header("Location: authentifier.php?error=true");
    }
}
else {
    // En GET : On affiche le formulaire
?>
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Authentification - Bienvenue sur MonJournal !</title>
    </head>
    <body>
        <h1>
            Bienvenue sur MonJournal !
        </h1>
        <h2>
            Authentification
        </h2>
        <!-- On test si le paramètre error est présent (erreur d'authentification) -->
        <?php
            if(isset($_GET['error']) && $_GET['error'] == "true") {
        ?>
            <p style="color: red;">Erreur d'authentification</p>
        <?php
            }
        ?>
        <form action="authentifier.php" method="post">
            <div>
                <label for="identifiant">Identifiant :</label> 
                <input type="text" name="identifiant" id="identifiant" />
            </div>
            <div>
                <label for="mot_de_passe">Mot de passe :</label> 
                <input type="password" name="mot_de_passe" id="mot_de_passe" />
            </div>
            <div>
                <button type="submit">Valider</button>
            </div>
        </form>
    </body>
    </html>
<?php
}
?>