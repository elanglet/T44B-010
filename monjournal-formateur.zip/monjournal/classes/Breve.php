<?php

class Breve extends Publication {
    // ...
}

