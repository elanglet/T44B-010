<?php

class ArticleDAO {

    public static function rechercherTousLesArticles(): ?array {
        $cxn = null;
        try {
            $cnx = DBUtil::connexion();
            $stmt = $cnx->prepare("SELECT * FROM article a JOIN auteur t ON a.auteur = t.identifiant");
            $stmt->execute();

            $listeArticles = [];
            while($enreg = $stmt->fetch()) {
                $auteur = new Auteur(
                    $enreg['identifiant'],
                    $enreg['motdepasse'],
                    $enreg['prenom'],
                    $enreg['nom']
                );
                $article = new Article(
                    $enreg['id'],
                    $enreg['titre'],
                    $enreg['intro'],
                    $enreg['texte'],
                    true,
                    $auteur
                );
                $article->setDate($enreg['date']);
                $listeArticles[] = $article;
            }
            return $listeArticles;
        }
        catch(PDOException $e) {
            throw new JournalException(
                "Erreur lors de la récupération de la liste des articles. Message technique : "
                 . $e->getMessage()
            );
        }
        finally {
            $cnx = null;
        }
    }

    public static function rechercherArticleParId(int $id): ?Article {
        $cxn = null;
        try {
            // Connexion (En utilisant la classe utilitaire)
            $cnx = DBUtil::connexion();

            // Préparation de la requête
            $stmt = $cnx->prepare(
                "SELECT a.titre,a.intro,a.texte,a.date,t.identifiant,t.motdepasse,t.prenom,t.nom FROM article a "
              . "JOIN auteur t ON a.auteur = t.identifiant WHERE a.id=:theId"
            );

            // Exécution de la requête. On remplace :theId par sa valeur.
            $stmt->execute(['theId' => $id]);

            // On a 1 enreg. ou 0 
            if($enreg = $stmt->fetch()) {
                // On créé l'auteur
                $auteur = new Auteur(
                    $enreg['identifiant'],
                    $enreg['motdepasse'],
                    $enreg['prenom'],
                    $enreg['nom']
                );
                $article = new Article(
                    $id,
                    $enreg['titre'],
                    $enreg['intro'],
                    $enreg['texte'],
                    true,
                    $auteur
                );
                $article->setDate($enreg['date']);
                return $article;
            }
            else {
                throw new JournalException("Article introuvable.");
            }       
        }
        catch(PDOException $e) {
            // On lève une JournalException
            throw new JournalException(
                "Erreur lors de la récupération de l'article. Message technique : "
                 . $e->getMessage()
            );
        }
        finally {
            $cnx = null;
        }
    }

    public static function ajouterArticle(Article $article): ?int {
        $cxn = null;
        try {
            $cnx = DBUtil::connexion();
            $stmt = $cnx->prepare(
                "INSERT INTO article(titre,intro,texte,date,auteur) " . 
                "VALUES(:theTitre,:theIntro,:theTexte,:theDate,:theAuteur)"
            );
            $stmt->execute(
                [
                    'theTitre'  => $article->getTitre(),
                    'theIntro'  => $article->getIntro(),
                    'theTexte'  => $article->getTexte(),
                    'theDate'   => $article->getDate(),
                    'theAuteur' => $article->getAuteur()->getIdentifiant()
                 ]
            );

            return $cnx->lastInsertId();
        }
        catch(PDOException $e) {
            throw new JournalException(
                "Erreur lors de l'ajout de l'article. Message technique : "
                 . $e->getMessage()
            );
        }
        finally {
            $cnx = null;
        }
    }
}
