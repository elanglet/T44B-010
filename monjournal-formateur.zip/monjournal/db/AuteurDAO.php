<?php

class AuteurDAO {

    // Type de retour : ?Auteur = Auteur ou NULL
    // La méthode ne renvoie rien quand une exception est levée.
    public static function authentifier(string $identifiant, string $motDePasse): ?Auteur {
        $cxn = null;
        try {
            $cnx = DBUtil::connexion();
            $stmt = $cnx->prepare(
                "SELECT nom,prenom FROM auteur WHERE identifiant=:theIdentifiant AND motdepasse=:theMotdepasse"
            );
            $stmt->execute(
                [  
                    'theIdentifiant' => $identifiant,
                    'theMotdepasse' => $motDePasse
                ]
            );

            if($enreg = $stmt->fetch()) {
                // On créé l'auteur
                $auteur = new Auteur(
                    $identifiant,
                    $motDePasse,
                    $enreg['prenom'],
                    $enreg['nom']
                );
                return $auteur;
            }
            else {
                throw new JournalException("Erreur d'authentification.");
            }       
        }
        catch(PDOException $e) {
            // On lève une JournalException
            throw new JournalException(
                "Erreur lors de l'authentification de l'auteur'. Message technique : "
                 . $e->getMessage()
            );
        }
        finally {
            $cnx = null;
        }
    }
}
